function savestats=locatebeads(filename,thresh,varargin);
% stats=locatebeads(filename,threshold,[framelist]);
% extracts COM, area, and framenumber from a TIFF stack file.
% threshold is level (0 < thresh < 1) for thresholding.  NB it's inverted relative to Scion image 
% (black <-> white).  Going some 5 to 7 sigma out from the black bkgnd usually works pretty well.
% framelist is an optional vector of the frames to be processed (e.g. 10:300)
fileinfo = imfinfo(filename); % Find out about the image file.
width = fileinfo(1).Width; height = fileinfo(1).Height; 
nFrames=length(fileinfo); clear fileinfo;
if nargin==2, % depending on calling syntax,
    framelist=1:50;
%     framelist=1:180; % change how many frames want to evaluate 
%     framelist=1:nFrames; % process all frames or
else
    framelist=varargin{1}; % only process frames requested in 3rd argument.
end;
bwstack = logical(zeros(height,width)); % save all thresholded images here if you want to debug.  

savestats=[]; % accumulate all the position, size, and frame information here
% Load the frames one at a time.  
% Threshold and close objects immediately (in function threshold).
% Label objects and retrieve their statistics (area, centroid)
% Append this data to savestats, where it's stored for future tracking analysis
% If desired, build up bwstack of thresholded images for debug/display purposes
for index=framelist, % load up the thresholded-image stack with 'nFrames' images
    fprintf(1,'.'); % so I know it hasn't crashed while it's running...
    bw=threshold(filename,index,thresh); % my threshold function is below.
    L=bwlabel(bw); % 'particle' assignment
    stats=regionprops(L,'area','centroid'); % retrieve some of the 'particle' properties 
    if ~isempty(stats), % empty stats causes crash
        [stats(1:length(stats)).Frame]=deal(index);
        savestats=[savestats; stats]; % accumulate to output variable.
    end;
    % bwstack(1:height,1:width,index)=bw; % NB this is slow and memory-intensive.
end; % loop over all frames.

function bw=threshold(filename,framenumber,cutoff); % All thresholding and image processing occurs here.
% This is the place to tweak the binary image processing.
im=imread(filename,framenumber); % This is a matlab image-processing toolbox fn.  Should handle jpeg,tiff...
bw=im2bw(im,cutoff); % matlab's thresholding function.
se=strel('disk',15); bw=imclose(bw,se); % matlab's close function w/ circular kernel.
bw=bwareaopen(bw,3); % squeeze out objects less than 3 pixels large (I think)


imshow(im);  % show original image 
