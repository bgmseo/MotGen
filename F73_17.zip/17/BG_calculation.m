close all
load ('tracks_conn_F73_17.mat')

dt=0.05;m_traj =0;
moving_index_F73_17=[];
for i=1:length(tracks_conn)
    x = tracks_conn(i).x; dx = diff(x).*0.568;
    y = tracks_conn(i).y; dy = diff(y).*0.568;
    dr = sqrt(dx.^2+dy.^2); %euclidean distance
    path = sum(dr); %sum of dr
    d_temp = sqrt((x(end)-x(1))^2+(y(end)-y(1))^2);
    displacement = d_temp *0.568;
    directionality = displacement/path;
    
    e_time = length(tracks_conn(i).frame) * (10/200); % unit: seconds
    n=length(x);
    %
    if displacement > 15 && path >25  %traveled length in micron
        m_traj = m_traj + 1; %number of moving object
        moving_index_F73_17(end+1) =i;
    end
    mov_p = (m_traj/length(tracks_conn))*100;
    
    % angle, velocities
    dxdt=zeros(n,1); dydt=zeros(n,1); drdt=zeros(1,n);
    ang=zeros(1,n);
    
    for jj=3:n-2
        dxdt(jj)=(2/(3*dt))*((x(jj+1)-x(jj-1)))-(1/(12*dt))*((x(jj+2)-x(jj-2)));
        dydt(jj)=(2/(3*dt))*((y(jj+1)-y(jj-1)))-(1/(12*dt))*((y(jj+2)-y(jj-2)));
    end
    drdt=sqrt(dxdt.^2 +dydt.^2);
    avg_V = (path/e_time); %average velocity of each tracks (micron per seconds)
    
    ang = atan2d(dydt,dxdt);
    change_ang = abs(diff(ang)); %absolute value
    
    if isempty(change_ang)
        change_ang = 0;
    end
    
    berg{i} = {dxdt,dydt,ang',drdt,change_ang'};
    F73_17{i} = {drdt, ang, path, displacement, directionality, e_time,avg_V};
end
fprintf("Numb of moving: %d, observed objects: %d, percentage of moving: %.2f%% \n",...
    m_traj, length(tracks_conn), mov_p);

save 'moving_index_F73_17.mat' moving_index_F73_17
save 'movingP_F73_17.mat'  mov_p


%%  전체 cell numbered plot
f10 = figure(10);
for k=1:length(tracks_conn)
    figure(f10);
    plot(tracks_conn(k).x,tracks_conn(k).y,'.')
    text(tracks_conn(k).x(1),tracks_conn(k).y(1),num2str(k),'FontSize',12);
    hold on;
    grid on
    axis([0 544 0 440]);
    title('F73_17 all','Interpreter','none')
end
savefig(f10, 'F73_17_all.fig')
%%  Moving cell만 plot
f9 = figure(9);
for k=1:length(tracks_conn)
    figure(f9);
    for kk = 1:length(moving_index_F73_17)
        if k == moving_index_F73_17(kk)
            plot(tracks_conn(k).x,tracks_conn(k).y,'.')
            text(tracks_conn(k).x(1),tracks_conn(k).y(1),num2str(moving_index_F73_17(kk)),'FontSize',12);
            hold on;
            grid on
            axis([0 544 0 440]);
            title('F73_17 Moving Trajectory #:',kk,'Interpreter','none')
            
        end
    end
end
savefig(f9, 'F73_17_moving.fig')
%% Berg의 run/tumble 기준 (35도)
for k = 1:length(tracks_conn)
    run=0; tumble=1;
    b_angle = berg{1,k}{1,5}; %change of angle in absolute value
    run_index =[]; tumble_index =[1];
    degree = 35;
    all = [2];
    for kk = 2: length(berg{1,k}{1,5})
        if kk <= length(berg{1,k}{1,5})-1
            if b_angle(kk-1)<= degree && b_angle(kk) <=degree && b_angle(kk+1) <=degree
                run = run + 1; % number of running cell
                run_index(end+1)=kk;
                all(kk)=1;
            elseif b_angle(kk-1)< degree && b_angle(kk) <degree
                run = run + 1; % number of running cell
                run_index(end+1)=kk;
                all(kk)=1;
            elseif b_angle(kk) > degree
                dx1 = berg{1, k}{1, 1}(kk-1)+ berg{1, k}{1, 1}(kk);
                dy1 = berg{1, k}{1, 2}(kk-1)+ berg{1, k}{1, 2}(kk);
                dx2 = berg{1, k}{1, 1}(kk+1)+ berg{1, k}{1, 1}(kk+2);
                dy2 = berg{1, k}{1, 2}(kk+1)+ berg{1, k}{1, 2}(kk+2);
                sum_a1 = abs(atan2d(dy1,dx1)); % vector sum's angle
                sum_a2 = abs(atan2d(dy2,dx2));
                sum_a = abs(sum_a2 -sum_a1);
                if sum_a >degree
                    tumble = tumble +1;
                    tumble_index(end+1) = kk;
                    all(kk)=2;
                else
                    run = run +1;
                    run_index(end+1)=kk;
                    all(kk)=1;
                end
            else
                tumble = tumble +1;
                tumble_index(end+1) =kk;
                all(kk)=2;
            end
        end
    end
    RT_stat{1,k} =run;%run total count
    RT_stat{2,k} =run_index; % running cell's index
    RT_stat{3,k} =tumble;%run total count
    RT_stat{4,k} =tumble_index;%run total count
    RT_stat{5,k} =all;%run total count
end

%%  run/tumble cell motility 계산
% 전체 계산
% for i =1
for i = 1:length(tracks_conn)
    frames =tracks_conn(i).frame; % total frames
    run_frames = RT_stat{2,i}; % run frames
    t_frames = RT_stat{4,i}; %tumbled frames
    e_time = F73_17{1, i}{1, 4}  ; %elapsed time
    
    inst_run =  berg{1,i}{1,4}(run_frames); % avg run speed
    inst_tumb = berg{1,i}{1,4}(t_frames); % avg tumble speed
    w_r = berg{1,i}{1,5}(run_frames); %angular speed-run
    w_t = berg{1,i}{1,5}(t_frames); %angular speed-tumble
    
    run_diff = diff(run_frames); run_temp = find([run_diff inf]>1);
    run_interval = diff([0 run_temp]);
    tumb_diff= diff(t_frames); tumb_temp = find([tumb_diff inf]>1);
    tumb_interval = diff([0 tumb_temp]);
    t_freq = length(t_frames)/length(frames);
    
    RT_calc_F73_17{1,i} = inst_run'; % avg run speed
    RT_calc_F73_17{2,i} = w_r;
    RT_calc_F73_17{3,i} = inst_tumb';
    RT_calc_F73_17{4,i} = w_t;
    RT_calc_F73_17{5,i} = run_interval;
    RT_calc_F73_17{6,i} = tumb_interval;
    RT_calc_F73_17{7,i} = RT_stat{5,i};
    F73_17{1,i}{1,8} = t_freq;
end
%% 저
save 'F73_17.mat' F73_17
save 'RT_calc_F73_17.mat' RT_calc_F73_17;