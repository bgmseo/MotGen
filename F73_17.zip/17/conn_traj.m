function tracks_conn = conn_traj(tracks, track_mode, dist_treshold) % track_mode 1.abs distance 2.heading angle 3.speed 

f1 = figure(1); %f2 = figure(2);
tracks_conn(1) = tracks(1);   % 첫번째 trajectory는 그대로 save
% dist_treshold = 10;  % pixel

for i=1:length(tracks)
   figure(f1);
   plot(tracks(i).x, tracks(i).y,'.')
   hold on; axis([0 544 0 440]);
   title('original trajectory #:',i)
   
   num_tracks_conn = length(tracks_conn); % 현재 저장되어 있는 connected trajectory 갯수
   dist_diff = zeros(1,num_tracks_conn); frame_diff = zeros(1,num_tracks_conn); len_tracks_conn = zeros(1,num_tracks_conn); 
   len_tracks = length(tracks(i).x); %저장되어 있는 connected trajectory와 비교하려고 하는 trajectory 하나의 길이
   saved_cnt = zeros(1,num_tracks_conn);

   if i>1
       % connected trajectory에 저장
       for j=1:num_tracks_conn
           len_tracks_conn(j) = length(tracks_conn(j).x); 
           
           % The Last position of Saved Connected Trajectory (x, y, frame)
           x_conn_last = tracks_conn(j).x(len_tracks_conn(j)); 
           y_conn_last = tracks_conn(j).y(len_tracks_conn(j)); 
           frame_conn_last = tracks_conn(j).frame(len_tracks_conn(j));
           
           % The First position of New Trajectory (x, y, frame)
           x_first = tracks(i).x(1); 
           y_first = tracks(i).y(1);
           frame_first = tracks(i).frame(1);
           
           dist_diff(j) = sqrt((x_first-x_conn_last)^2 + (y_first-y_conn_last)^2); 
           frame_diff(j) = frame_first - frame_conn_last;           
           
           if  dist_diff(j) <= dist_treshold && frame_diff(j) > 0
              saved_cnt(j) = saved_cnt(j) + 1; 
           end 
       end
       
       is_multiple=0;
       
       [~,ind_min] = min(dist_diff);
       idx_select_size = ind_min; % based on abs distance difference

       if sum(saved_cnt)>1
           is_multiple=1; is_comp = 0; temp_idx = find(saved_cnt==1);           
           for l = 1:length(temp_idx)
               % heading angle compare
               length_traj_temp = length(tracks_conn(temp_idx(l)).y);
               if length_traj_temp>1
                   is_comp = 1; % heading angle & speed compare                     
                   
                   % Heading Angle Compare with newly introduced point and the end of the trajectories
                   heading_angle_track(l) = atan2((tracks_conn(temp_idx(l)).y(length_traj_temp)-tracks_conn(temp_idx(l)).y(length_traj_temp-1)), (tracks_conn(temp_idx(l)).x(length_traj_temp)-tracks_conn(temp_idx(l)).x(length_traj_temp-1)));
                   new_heading_candidate(l) = atan2((tracks(i).y(1)-tracks_conn(temp_idx(l)).y(length_traj_temp)), (tracks(i).x(1)-tracks_conn(temp_idx(l)).x(length_traj_temp)));         

                   % Speed changes with newly introduced point and the end of the trajectories
                   speed_track(l) = sqrt((tracks_conn(temp_idx(l)).y(length_traj_temp)-tracks_conn(temp_idx(l)).y(length_traj_temp-1))^2 + (tracks_conn(temp_idx(l)).x(length_traj_temp)-tracks_conn(temp_idx(l)).x(length_traj_temp-1))^2);
                   new_speed_candidate(l) = sqrt((tracks(i).y(1)-tracks_conn(temp_idx(l)).y(length_traj_temp))^2 + (tracks(i).x(1)-tracks_conn(temp_idx(l)).x(length_traj_temp))^2);
               else
                   is_comp = 0;
               end
           end
           
           if (is_comp)
               diff_heading_angle = new_heading_candidate - heading_angle_track;
               [~,ind_min_angle] = min(abs(diff_heading_angle));
               idx_select_angle = temp_idx(ind_min_angle); % based on the heading angle    
           
               diff_speed = new_speed_candidate - speed_track;
               [~,ind_min_speed] = min(abs(diff_speed));
               idx_select_speed = temp_idx(ind_min_speed); % based on the speed
               
%                if (idx_select_angle==idx_select_speed) && (idx_select_speed==idx_select_size) % 세가지 방법으로 모두 같은 traj 선택
%                    idx_select = idx_select_angle; 
%                elseif idx_select_angle==idx_select_speed
%                    idx_select = idx_select_angle; 
%                elseif idx_select_angle==idx_select_size
%                    idx_select = idx_select_angle;                   
%                elseif idx_select_speed==idx_select_size
%                    idx_select = idx_select_speed;                   
%                else % 세가지 방법이 모두 다른 경우                    
%                    idx_select = idx_select_angle; % 하나를 선택해야 함. 
%                    
%                  % 그려서 확인                    
% %                    figure(f2); plot(tracks(i).x, tracks(i).y,'.'); hold on; plot(tracks(i).x(1), tracks(i).y(1),'*'); Legend = cell(length(temp_idx)+1,1); grid on;                    
% %                    Legend{1} = 'New track'; Legend{2} = 'New track startpoit'; 
% %                    for l = 1:length(temp_idx)
% %                        plot(tracks_conn(temp_idx(l)).x, tracks_conn(temp_idx(l)).y,'.');                        
% %                        Legend{l*2+1} = strcat('traj # ', num2str(temp_idx(l)));            
% %                        plot(tracks_conn(temp_idx(l)).x(end), tracks_conn(temp_idx(l)).y(end),'*'); 
% %                        Legend{l*2+2} = strcat('traj endpoint', num2str(temp_idx(l)));            
% %                    end                                    
% %                    legend(Legend); 
% %                    hold off;
%                    
%                      if (tracks(i).x(1) > 384 && tracks(i).x(1) < 388) && (tracks(i).y(1) > 108 && tracks(i).y(1) <126)
%                         a=2;
%                      end
%                end
                              
               switch track_mode
                   case 1
                       idx_select = idx_select_size;
                   case 2
                       idx_select = idx_select_angle;
                   case 3
                       idx_select = idx_select_speed;
               end
           else
               idx_select = idx_select_size; % based on abs distance difference
           end
                      
           heading_angle_track = 0; new_heading_candidate = 0; speed_track = 0; new_speed_candidate = 0;
       end
       
      % 비교      
      is_tracks_conn = 0;
      for j=1:num_tracks_conn             
          if dist_diff(j) <= dist_treshold && is_multiple==0               
             if frame_diff(j) == 1
                 tracks_conn(j).x(len_tracks_conn(j)+1:len_tracks_conn(j)+len_tracks) = tracks(i).x;
                 tracks_conn(j).y(len_tracks_conn(j)+1:len_tracks_conn(j)+len_tracks) = tracks(i).y;
                 tracks_conn(j).frame(len_tracks_conn(j)+1:len_tracks_conn(j)+len_tracks) = tracks(i).frame;
                 is_tracks_conn = 1;
             elseif frame_diff(j) > 1
                 tracks_conn(j).x(len_tracks_conn(j)+frame_diff(j):len_tracks_conn(j)+len_tracks+frame_diff(j)-1) = tracks(i).x;
                 tracks_conn(j).y(len_tracks_conn(j)+frame_diff(j):len_tracks_conn(j)+len_tracks+frame_diff(j)-1) = tracks(i).y;
                 tracks_conn(j).frame(len_tracks_conn(j)+frame_diff(j):len_tracks_conn(j)+len_tracks+frame_diff(j)-1) = tracks(i).frame;
                 
                 % interpolation
                 tracks_conn(j).x(len_tracks_conn(j):len_tracks_conn(j)+frame_diff(j)) = linspace(tracks_conn(j).x(len_tracks_conn(j)), tracks(i).x(1), frame_diff(j)+1);
                 tracks_conn(j).y(len_tracks_conn(j):len_tracks_conn(j)+frame_diff(j)) = linspace(tracks_conn(j).y(len_tracks_conn(j)), tracks(i).y(1), frame_diff(j)+1);
                 tracks_conn(j).frame(len_tracks_conn(j):len_tracks_conn(j)+frame_diff(j)) = linspace(tracks_conn(j).frame(len_tracks_conn(j)), tracks(i).frame(1), frame_diff(j)+1);       
                 is_tracks_conn = 1;
             end
          elseif dist_diff(j) <= dist_treshold && is_multiple==1
              j=idx_select;
              if frame_diff(j) == 1
                 tracks_conn(j).x(len_tracks_conn(j)+1:len_tracks_conn(j)+len_tracks) = tracks(i).x;
                 tracks_conn(j).y(len_tracks_conn(j)+1:len_tracks_conn(j)+len_tracks) = tracks(i).y;
                 tracks_conn(j).frame(len_tracks_conn(j)+1:len_tracks_conn(j)+len_tracks) = tracks(i).frame;
                 is_tracks_conn = 1;
             elseif frame_diff(j) > 1
                 tracks_conn(j).x(len_tracks_conn(j)+frame_diff(j):len_tracks_conn(j)+len_tracks+frame_diff(j)-1) = tracks(i).x;
                 tracks_conn(j).y(len_tracks_conn(j)+frame_diff(j):len_tracks_conn(j)+len_tracks+frame_diff(j)-1) = tracks(i).y;
                 tracks_conn(j).frame(len_tracks_conn(j)+frame_diff(j):len_tracks_conn(j)+len_tracks+frame_diff(j)-1) = tracks(i).frame;
                 
                 % interpolation
                 tracks_conn(j).x(len_tracks_conn(j):len_tracks_conn(j)+frame_diff(j)) = linspace(tracks_conn(j).x(len_tracks_conn(j)), tracks(i).x(1), frame_diff(j)+1);
                 tracks_conn(j).y(len_tracks_conn(j):len_tracks_conn(j)+frame_diff(j)) = linspace(tracks_conn(j).y(len_tracks_conn(j)), tracks(i).y(1), frame_diff(j)+1);
                 tracks_conn(j).frame(len_tracks_conn(j):len_tracks_conn(j)+frame_diff(j)) = linspace(tracks_conn(j).frame(len_tracks_conn(j)), tracks(i).frame(1), frame_diff(j)+1);       
                 is_tracks_conn = 1;
             end
              break;
          end
      end
      
      if ~(is_tracks_conn)
          tracks_conn(num_tracks_conn+1) = tracks(i);  % 새로운 트랙으로 저장
      end
      
   end   
end



end
