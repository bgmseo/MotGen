% close all; clc
load('../F73_bead/tracks_F73_17.mat'); 

%% 전 코드와 함께 쓸거면, 아래 내용만 사용하면 됨. 
tracks_conn = conn_traj(tracks,3,20); 
% input 1.original tracks, 2. mode (track_mode 1.abs distance 2.heading angle 3.speed), 3. dist threshold (px)
num_tracks_conn = length(tracks_conn);
f2 = figure(2); 
for k=1:num_tracks_conn
   figure(f2);
   plot(tracks_conn(k).x, tracks_conn(k).y,'.')
   hold on;
%    plot(pos_x{k,1}(1),pos_y{k,1}(1),num2str(moving_index(kk)),'FontSize',12);

   hold on; axis([0 544 0 440]);
   title('F73_17 Connected trajectory #:',k)
%     pause();
end
%%
save 'tracks_conn_F73_17.mat' tracks_conn
